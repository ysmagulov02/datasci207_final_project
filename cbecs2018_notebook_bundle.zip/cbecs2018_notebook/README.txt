CBECS preprocessing and variable evidence

Owner: Yera Smagulov. Unzip this folder, install requirements.txt, open
notebooks/01_data_preprocessing_ysmagulov.ipynb, and run cells in order.
The notebook has 21 numbered cells and 9 executed code cells.
The feature-screening model can take a little longer than basic preprocessing.

Inputs are in data/raw. Processed files are in data/processed. The dataset has
6,357 rows, ten source predictors, and 91 encoded inputs. In the combined
CSV, exclude PUBID, split, and MFBTU from X. MFBTU is y in kBtu.
Use X_<split>_tree for boosting and X_<split>_scaled for linear regression/FNN.
Targets and metadata match feature-file row order. Splits: 4,449/954/954.

feature_evidence/ contains the numeric correlation matrix, candidate ranking,
permutation details, screening-fold errors, and selected variables. Screening
uses only the training partition. This is not a final model comparison.
The two lowest selected effects are tentative. A concise training-only EDA
figure and two summary tables are in figures/eda. The figure appears in the notebook.
Rerunning the notebook replaces its generated files.
